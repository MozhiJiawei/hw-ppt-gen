const path = require("path");
const {
  addCoverSlide,
  addTocSlide,
  createHuaweiDeck,
  ensureTmpPath,
} = require("../../scripts/pptx/hw_pptx_helpers");
const {
  addVisualAnchorContentSlide,
  writeVisualAnchorManifest,
} = require("../../scripts/pptx/hw_visual_anchor_slide");

process.env.HW_VISUAL_ANCHOR_RENDERER = "rough_svg";

const deck = "asic_ai_supply_chain_20260503";
const outDir = path.join(".tmp", deck);
const pptxPath = ensureTmpPath(path.join(outDir, `${deck}.pptx`));
const manifestPath = ensureTmpPath(path.join(outDir, `${deck}_visual_anchor_manifest.json`));
const sourceShort = "来源：经济日报、TrendForce、Investing.com，2026";
const sections = ["新闻概览", "市场信号", "产业链影响", "风险与观察"];

function contentSlide(data) {
  return addVisualAnchorContentSlide(pptx, {
    sections,
    source: data.source || sourceShort,
    ...data,
  });
}

const pptx = createHuaweiDeck({
  title: "云端自研 ASIC 升温：AI 服务器供应链再定价",
  subject: "2026-05-03 财经新闻解读",
  author: "Codex",
});

addCoverSlide(pptx, {
  title: "云端自研 ASIC 升温",
  subtitle: "AI 服务器供应链再定价",
  department: "今日新闻商业解读",
  date: "2026.05.03",
});

addTocSlide(pptx, {
  title: "目录 CONTENTS",
  items: [
    { title: "新闻概览", note: "从 5 月 3 日财经新闻提炼主线" },
    { title: "市场信号", note: "CSP 资本开支与 AI Server 出货共振" },
    { title: "产业链影响", note: "ASIC 设计、制造、封测与组装的价值映射" },
    { title: "风险与观察", note: "客户集中、产能、技术验证与估值消化" },
  ],
  source: sourceShort,
  page: "02",
});

contentSlide({
  title: "新闻主线",
  titleNote: "云端自研芯片把台系 ASIC 供应链推到台前",
  currentSection: "新闻概览",
  page: "03",
  summary: {
    body: [
      { label: "事件聚焦", text: "经济日报 5 月 3 日报道，Google、AWS 等自研芯片大量出货，带动联发科、世芯、创意等 ASIC 业者机会。" },
      { label: "数字支撑", text: "联发科首个 AI ASIC 项目预估第 4 季贡献约 20 亿美元，2027 年市场规模看 700亿-800 亿美元。" },
      { label: "产业外溢", text: "AI Server 年增 28%以上与 ASIC 占比提升，使代工、封测、载板和组装链同步受关注。" },
    ],
  },
  anchorArea: { x: 0.55, y: 2.47, w: 7.55, h: 4.35 },
  visual_anchor: {
    id: "news_key_numbers",
    title: "News Key Numbers",
    claim: "当日新闻的关键数字显示 ASIC 已成为 AI 基建变量。",
    kind: "Quantity",
    template: "data_cards",
    visual_spec: {
      cards: [
        { id: "mediatek_q4", label: "联发科收入", value: "20", unit: "亿美元" },
        { id: "tam_2027", label: "ASIC 市场", value: "750", unit: "亿美元" },
        { id: "ai_server_growth", label: "AI 服务器", value: "28+", unit: "%" },
        { id: "asic_share", label: "ASIC 占比", value: "27.8", unit: "%" },
      ],
      highlight: "mediatek_q4",
    },
  },
  visualAnchorCaption: {
    text: "新闻数字：ASIC 机会从题材进入收入与出货验证期",
    source: "经济日报 2026-05-03；TrendForce 2026-01-20",
  },
  supportingCards: [
    {
      title: "为什么今天重要",
      body: [
        "新闻把美国云端自研芯片与台系供应链直接相连。",
        "收入、市场规模、出货占比均已有可跟踪数字。",
      ],
    },
    {
      title: "核心判断",
      body: [
        "GPU 仍是主流，ASIC 正切入推理负载。",
        "供应链机会不止芯片设计，也覆盖制造和系统整合。",
      ],
    },
  ],
});

contentSlide({
  title: "需求路径",
  titleNote: "从推理流量到定制芯片订单的四段传导",
  currentSection: "新闻概览",
  page: "04",
  summary: {
    body: [
      { label: "需求起点", text: "推理服务把云端算力需求从训练扩展到日常流量承载，AI Agent、Copilot、Gemini 是典型入口。" },
      { label: "架构选择", text: "云端大厂同时采购 GPU 平台并推进自研 ASIC，以优化成本、功耗和工作负载适配。" },
      { label: "兑现路径", text: "芯片量产后，设计服务、晶圆代工、先进封装、载板和服务器组装分段受益。" },
    ],
  },
  anchorArea: { x: 0.55, y: 2.47, w: 7.65, h: 4.35 },
  visual_anchor: {
    id: "demand_transmission_path",
    title: "Demand Transmission Path",
    claim: "云端自研 ASIC 的商业化需要从流量、设计、制造到系统交付连续兑现。",
    kind: "Sequence",
    template: "process",
    visual_spec: {
      steps: [
        { id: "traffic", label: "推理流量增长" },
        { id: "capex", label: "CSP 扩大资本开支" },
        { id: "asic", label: "自研 ASIC 量产" },
        { id: "supply", label: "台系链条放量" },
      ],
      highlight: "asic",
      orientation: "horizontal",
    },
  },
  visualAnchorCaption: {
    text: "传导路径：云端需求先变成资本开支，再变成 ASIC 与系统订单",
    source: "TrendForce 2026-01-20；经济日报 2026-05-03",
  },
  supportingCards: [
    {
      title: "需求端",
      body: [
        "Google、AWS、Meta、Microsoft 等是新增 AI 基建需求的核心来源。",
        "推理服务需要更低单位算力成本，给 ASIC 留出定位空间。",
      ],
    },
    {
      title: "供给端",
      body: [
        "设计公司绑定客户项目，量产节奏决定收入确认。",
        "代工、CoWoS、ABF 和整机交付能力成为约束变量。",
      ],
    },
  ],
});

contentSlide({
  title: "市场信号",
  titleNote: "AI Server 与 CSP CapEx 同时抬升",
  currentSection: "市场信号",
  page: "05",
  summary: {
    body: [
      { label: "增长明确", text: "TrendForce 预计 2026 年 AI Server 出货年增 28%以上，快于整体 Server 的 12.8%。" },
      { label: "资金加速", text: "八大 CSP 2026 年合计资本开支预计超过 7100 亿美元，同比约增 61%。" },
      { label: "结构变化", text: "ASIC AI Server 占比预计升至 27.8%，显示自研芯片从小众试点进入规模阶段。" },
    ],
  },
  anchorArea: { x: 0.55, y: 2.47, w: 7.5, h: 4.35 },
  visual_anchor: {
    id: "market_growth_bars",
    title: "Market Growth Bars",
    claim: "AI Server、CSP CapEx 与 ASIC 占比共同验证需求强度。",
    kind: "Quantity",
    template: "bar_chart",
    visual_spec: {
      y_label: "百分比",
      categories: ["整体 Server", "AI Server", "八大 CSP CapEx", "Google CapEx"],
      series: [
        { name: "2026 年增或占比", values: [12.8, 28, 61, 95] },
      ],
      highlight: { category: "八大 CSP CapEx", series: "2026 年增或占比" },
    },
  },
  visualAnchorCaption: {
    text: "市场信号：AI 基建扩张既有出货端，也有资本开支端",
    source: "TrendForce 2026-01-20；TrendForce 2026-02-25",
  },
  supportingCards: [
    {
      title: "读图提示",
      body: [
        "柱状图混合展示增长率，不代表同一口径规模。",
        "重点看方向：服务器与资本开支均上行。",
      ],
    },
    {
      title: "商业含义",
      body: [
        "CSP 投资强度提升，会延长订单能见度。",
        "ASIC 占比提升，使非 GPU 供应链获得更多议价叙事。",
      ],
    },
  ],
});

contentSlide({
  title: "受益链条",
  titleNote: "台系供应链承接设计、制造与系统价值",
  currentSection: "产业链影响",
  page: "06",
  summary: {
    body: [
      { label: "设计前移", text: "联发科、世芯、创意等 ASIC 设计与服务商直接承接 CSP 定制芯片项目。" },
      { label: "制造放大", text: "台积电、先进封装、ABF 载板和测试环节随 AI 芯片复杂度提升而受益。" },
      { label: "系统交付", text: "鸿海、广达、纬创等 AI 服务器组装厂受北美 CSP 需求带动，出货量成为观察指标。" },
    ],
  },
  anchorArea: { x: 0.55, y: 2.47, w: 12.23, h: 4.35 },
  visual_anchor: {
    id: "supply_chain_table",
    title: "Supply Chain Table",
    claim: "不同供应链环节承接不同的 ASIC 商业价值。",
    kind: "Matrix",
    template: "table",
    visual_spec: {
      rows: [
        ["环节", "代表公司", "需求驱动", "观察指标"],
        ["ASIC 设计", "联发科、世芯、创意", "Google、AWS、Microsoft 等定制项目", "量产时点、项目收入、市占目标"],
        ["晶圆与封装", "台积电、日月光、京元电", "先进制程、CoWoS、测试需求提升", "产能扩张、稼动率、外溢订单"],
        ["载板与材料", "欣兴、景硕、南电", "ABF 供应偏紧与高阶封装配套", "交期、价格、材料供给"],
        ["系统组装", "鸿海、广达、纬创", "北美 CSP AI 服务器出货增长", "机柜出货、客户结构、毛利率"],
      ],
    },
  },
  visualAnchorCaption: {
    text: "供应链映射：ASIC 不是单点机会，而是跨设计、制造、封测与系统交付的链条",
    source: "经济日报 2026-05-03",
  },
});

contentSlide({
  title: "价值转移",
  titleNote: "从标准硬件采购转向定制化协同",
  currentSection: "产业链影响",
  page: "07",
  summary: {
    body: [
      { label: "客户绑定", text: "ASIC 项目通常深度绑定 CSP 路线图，单一项目放量即可显著改变设计服务商收入曲线。" },
      { label: "能力升级", text: "竞争焦点从拿到订单扩展到系统架构、供应链协调、先进封装和量产执行。" },
      { label: "价值分层", text: "越靠近定制设计和关键产能，越可能获得更长订单能见度与更强议价能力。" },
    ],
  },
  anchorArea: { x: 0.55, y: 2.47, w: 7.55, h: 4.35 },
  visual_anchor: {
    id: "value_shift_stack",
    title: "Value Shift Stack",
    claim: "AI ASIC 价值沿着定制设计、关键制造和系统交付逐层展开。",
    kind: "Hierarchy",
    template: "capability_stack",
    visual_spec: {
      levels: [
        { label: "CSP 应用与推理流量" },
        { label: "ASIC 架构与设计服务" },
        { label: "先进制程与封装测试" },
        { label: "机柜系统与交付运维" },
      ],
      highlight: "ASIC 架构与设计服务",
    },
  },
  visualAnchorCaption: {
    text: "价值分层：自研芯片把供应链协同提前到芯片定义阶段",
    source: "经济日报 2026-05-03；TrendForce 2026-02-25",
  },
  supportingCards: [
    {
      title: "短期看点",
      body: [
        "联发科首个项目是否按期量产并贡献收入。",
        "世芯、创意是否继续拿到下一代 CPU 或推论芯片项目。",
      ],
    },
    {
      title: "中期看点",
      body: [
        "Google、AWS 等是否把 ASIC 从自用扩展到云服务客户。",
        "先进封装与 ABF 供给是否成为真实瓶颈。",
      ],
    },
  ],
});

contentSlide({
  title: "风险雷达",
  titleNote: "机会明确，但兑现仍看节奏与约束",
  currentSection: "风险与观察",
  page: "08",
  summary: {
    body: [
      { label: "客户集中", text: "ASIC 项目高度依赖少数 CSP，单一客户验证或采购节奏变化会放大业绩波动。" },
      { label: "产能约束", text: "先进制程、CoWoS、ABF 与 HBM 等供应链瓶颈可能影响出货节奏和成本。" },
      { label: "估值消化", text: "新闻热度会先进入股价预期，后续需要财报和订单能见度持续验证。" },
    ],
  },
  anchorArea: { x: 0.55, y: 2.47, w: 7.55, h: 4.35 },
  visual_anchor: {
    id: "risk_capability_matrix",
    title: "Risk Capability Matrix",
    claim: "ASIC 机会需要同时跟踪需求、技术、产能和估值四类风险。",
    kind: "Matrix",
    template: "capability_matrix",
    visual_spec: {
      rows: ["需求兑现", "技术验证", "产能供给", "估值预期"],
      columns: ["影响", "可观察性", "短期波动"],
      values: [
        [0.8, 0.7, 0.6],
        [0.7, 0.5, 0.7],
        [0.9, 0.6, 0.8],
        [0.6, 0.8, 0.9],
      ],
      highlight: { row: "产能供给", column: "影响" },
    },
  },
  visualAnchorCaption: {
    text: "风险矩阵：把新闻题材拆成可跟踪的经营信号",
    source: "基于新闻与 TrendForce 资料整理",
  },
  supportingCards: [
    {
      title: "优先跟踪",
      body: [
        "联发科第 4 季约 20 亿美元收入目标是否落地。",
        "Google、AWS、Microsoft 的芯片路线是否延续。",
      ],
    },
    {
      title: "风险边界",
      body: [
        "GPU 仍是 AI Server 主流，ASIC 是增量结构变化而非完全替代。",
        "单一项目放量与行业普遍受益需要区分。",
      ],
    },
  ],
});

writeVisualAnchorManifest(pptx, manifestPath);

pptx.writeFile({ fileName: pptxPath }).then(() => {
  console.log(`Wrote ${pptxPath}`);
  console.log(`Wrote ${manifestPath}`);
});
